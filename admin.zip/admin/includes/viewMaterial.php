<?php
    $QrConsulta = "SELECT 
	ma.Id, uu.Name Entrenador, ma.Id_entrenador, ma.Id_producto, p.Nombre, ma.Cantidad, ma.Fecha_asignacion, u.Name Usuario, ea.Tipo Estado,  ifnull(Fecha_devolucion, 'Sin devolucion') Fecha_dvl
FROM 
	mvto_asignacion ma
    INNER JOIN productos p on p.Id_producto = ma.Id_producto
    INNER JOIN usuario u on u.Id_usuario = ma.Id_usuario
    INNER JOIN estados_asignaciones ea on ea.Id = ma.Estado 
    INNER JOIN usuario uu on uu.Id_usuario = ma.Id_entrenador
ORDER BY ma.Estado, Fecha_asignacion DESC";
$VerPrestamos = $conexion -> query($QrConsulta);
?>

<ol class="breadcrumb"> 
    <li class="breadcrumb-item">Menu entrenadores</li>
    <li class="breadcrumb-item active">Ver material asignado.</li>
</ol>

<meta charset="utf-8">
  <div class="container-fluid">
    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0"> 
      <thead>
        <tr>
          <th>Producto</th>
          <th>Cantidad</th>
          <th>Fecha Solicitud</th>
          <th>Fecha Devolución</th>
          <th>Usuario</th> 
          <th>Entrenador</th> 
          <th>Estado</th> 
          <th>Acciones</th> 
        </tr>
      </thead>
<?php 
    while ($VerData=$VerPrestamos->fetch_array(MYSQLI_BOTH)) { 

    echo "<tr>
        <td>".$VerData['Nombre']."</td>
        <td align='center'>".$VerData['Cantidad']."</td>
        <td align='right'>".$VerData['Fecha_asignacion']."</td>
        <td align='right'>".$VerData['Fecha_dvl']."</td>
        <td>".$VerData['Usuario']."</td>
        <td>".$VerData['Entrenador']."</td>
        <td>".$VerData['Estado']."</td> 
        <td><form action='../admin/index.php?contenido=' method='POST' name='copia' target='_self'>
                <input type='button' name='view' value='Acciones' id='".$VerData['Id']."' class='btn btn-dark btn-block view_data'/>
        </form></td>
    </tr>";
    }      
?>
  </table>
</div>

<script>
 $(document).ready(function(){  
      $('#add').click(function(){  
           $('#insert').val("Insert");  
           $('#insert_form')[0].reset();  
      }); 
      $(document).on('click', '.view_data', function(){  
           var employee_id = $(this).attr("id");  
           if(employee_id != '')  
           {  
                $.ajax({  
                     url:"includes/modificarPrestamo.php",  
                     method:"POST",  
                     data:{employee_id:employee_id},  
                     success:function(data){  
                          $('#employee_detail').html(data);  
                          $('#dataModal').modal('show');  
                     }  
                });  
           }            
      });  
 });  
 </script>
 <div id="dataModal" class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">  
      <div class="modal-dialog modal-lg">  
           <div class="modal-content">  
                <div class="modal-header">
                  <h4 class="modal-title">Acciones del prestamo</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>      
                </div>  
                <div class="modal-body" id="employee_detail">  
                </div> 
                 
           </div>  
      </div>  
 </div>