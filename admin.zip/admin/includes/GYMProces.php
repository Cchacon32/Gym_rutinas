<?php

include 'conexion.php'; 
date_default_timezone_set('America/Bogota');

if (isset($_POST['aggRutina'])) {

	$Persona = $_POST['Persona'];
	$Fecha = $_POST['Fecha'];
	$Rutina = $_POST['Rutina'];
	$Enternador = $_POST['Enternador'];
	 
	$QueryRutina="INSERT INTO rutinas (Id_entrenador, Id_persona, Fecha_rutina, Rutina, Estado) VALUES ($Enternador, $Persona, '$Fecha', '$Rutina', 1)";

	if ($conexion ->query($QueryRutina)) { 

		$QueryVerPersonaMani="SELECT MAX(R.Id_rutina) AS Serial FROM rutinas R WHERE R.Id_entrenador = $Enternador AND R.Id_persona = $Persona AND Fecha_rutina = '$Fecha' ORDER BY R.Id_rutina DESC";
	    $siguiente=$conexion->query($QueryVerPersonaMani);
	    $final=mysqli_fetch_assoc($siguiente);
	    $Serial=$final['Serial'];

	    for ($i=1; $i <= $_POST['CantidadImagenes'] ; $i++) { 
			if (isset($_POST['Imagenes'.$i])) {
				$imagen = $_POST['Imagenes'.$i];
	    		$conexion ->query("INSERT INTO rutinas_imagenes(Id_Rutina, Id_imagen) VALUES ($Serial, $imagen)");
			}	
		}


        echo "<div class='container'>
            <div class='alert alert-dark alert-dismissible'>
                <strong>¡Se registro la rutina!</strong> El proceso se realizo de manera satisfactoria. muchas gracias.
            </div>
        </div>";

        ?>
        
        <form action="../admin/index.php?contenido=viewRutinas" method="POST" class="form-register" name="RVH"> 
			<input type="hidden" name="Serial" value="<?php echo $Serial; ?>">
			<input type="hidden" name="Enternador" value="<?php echo $Enternador; ?>">
			<input type="hidden" name="Persona" value="<?php echo $Persona; ?>">
			<input name="viewRutinas" class="btn btn-dark btn-block" type="submit" value="Ver Rutinas"/>
		</form>
        
   	<?php }else{
        echo "Algo ocurrio ... ".$QueryRutina;
  	}
}

if (isset($_POST['ActRutina'])) {

	$Persona = $_POST['Persona'];
	$Enternador = $_POST['Enternador'];
	$Fecha = $_POST['Fecha'];
	$Rutina = $_POST['Rutina'];
	$Serial = $_POST['Serial'];
	$Estado = $_POST['Estado'];

 	$QueryRutina="UPDATE rutinas SET Fecha_rutina = '$Fecha', Rutina = '$Rutina', Estado = $Estado WHERE Id_rutina = $Serial ";

	if ($conexion ->query($QueryRutina)) { 

		$conexion ->query("DELETE FROM `rutinas_imagenes` WHERE Id_rutina= $Serial");

		for ($i=1; $i <= $_POST['CantidadImagenes'] ; $i++) { 
			if (isset($_POST['Imagenes'.$i])) {
				$imagen = $_POST['Imagenes'.$i];
	    		$conexion ->query("INSERT INTO rutinas_imagenes(Id_Rutina, Id_imagen) VALUES ($Serial, $imagen)");
			}	
		}

        echo "<div class='container'>
            <div class='alert alert-dark alert-dismissible'>
                <strong>¡Se modifico la rutina!</strong> El proceso se realizo de manera satisfactoria. muchas gracias.
            </div>
        </div>";

        ?>
        
        <form action="../admin/index.php?contenido=viewRutinas" method="POST" class="form-register" name="RVH"> 
			<input type="hidden" name="Serial" value="<?php echo $Serial; ?>">
			<input type="hidden" name="Enternador" value="<?php echo $Enternador; ?>">
			<input type="hidden" name="Persona" value="<?php echo $Persona; ?>">
			<input name="viewRutinas" class="btn btn-dark btn-block" type="submit" value="Ver Rutinas"/>
		</form>
        
   	<?php }else{
        echo "Algo ocurrio ... ".$QueryRutina;
  	}
}

if (isset($_POST['EliminarRutina'])) {
 
	$Serial = $_POST['Dato']; 

	$QueryRutina="DELETE FROM rutinas WHERE Id_rutina = $Serial ";

	if ($conexion ->query($QueryRutina)) { 

        echo " 
            <div class='alert alert-danger alert-dismissible'>
                <strong>¡Se elimino la rutina!</strong> El proceso se realizo de manera satisfactoria. muchas gracias. 
        </div>";

        ?>
        
        <form action="../admin/index.php?contenido=viewRutinasGeneral" method="POST" class="form-register" name="RVH"> 
			 <input name="viewRutinas" class="btn btn-danger btn-block" type="submit" value="Ver Rutinas"/>
		</form>
        
   	<?php }else{
        echo "Algo ocurrio ... ".$QueryRutina	;
  	}
}

if (isset($_POST['EditPersona'])) {

	$Cedula=$_POST['Cedula'];
	$Name=$_POST['Name'];
	$Password=$_POST['Password'];
	$Entrenador=md5($_POST['Entrenador']);
	$Estado=$_POST['Estado'];

	$QueryRutina="UPDATE usuario SET Name = '$Name', Password = '$Password', Entrenador = '$Entrenador', Estado = $Estado WHERE Id_usuario = $Cedula ";

	if ($conexion ->query($QueryRutina)) { 

        echo "<div class='container'>
            <div class='alert alert-dark alert-dismissible'>
                <strong>¡Se modifico el usuario!</strong> El proceso se realizo de manera satisfactoria. muchas gracias.
            </div>
        </div>";

	        if ($Entrenador == $Cedula) {
	        	echo "
	        	<form action='../admin/index.php?contenido=aggEntrenadores' method='POST' class='form-register' name='RVH'>  
					<input name='viewRutinas' class='btn btn-dark btn-block' type='submit' value='Ver Entrenadores'/>
				</form>";
	        }else{ 
	        	echo "
	        	<form action='../admin/index.php?contenido=aggPersonas' method='POST' class='form-register' name='RVH'>  
					<input name='viewRutinas' class='btn btn-dark btn-block' type='submit' value='Ver Personas'/>
				</form>";
	        }
    }else{
        echo "Algo ocurrio ... ".$QueryRutina	;
  	}
}

if(isset($_POST['LlegadaSalida'])){
	$Cedula = $_POST['Cedula'];
	$Estado = $_POST['Estado'];

	if($Estado == 1){
		$Fecha = date("Y-m-d");
		$QueryInsert = "INSERT INTO asistencia (Cedula, FechaIng, FechaSal, Fecha, Estado) VALUES ($Cedula, NOW(), NULL, '$Fecha', 1)";
		if($conexion -> query($QueryInsert)){
			echo "<div class='alert alert-dark alert-dismissible'>
				<strong>¡Se registro el dato!</strong> Gracias por registrar la hora llegada. 
			</div>"; ?>			
			<form action="../admin/index.php?contenido=menupersonas" method="POST" class="form-register" name="RVH"> 
				<input class="btn btn-dark btn-block" type="submit" value="Volver"/>
			</form>
			<?php
		}
	}else{
		$QueryUpdate = "UPDATE asistencia SET FechaSal = NOW(), Estado = 2 WHERE Id_asistencia = ".$_POST['Id_asistencia'];
		if($conexion -> query($QueryUpdate)){
			echo "<div class='alert alert-dark alert-dismissible'>
				<strong>¡Se registro el dato!</strong> Gracias por registrar la hora de salida. 
			</div>"; ?>			
			<form action="../admin/index.php?contenido=menupersonas" method="POST" class="form-register" name="RVH"> 
				<input class="btn btn-dark btn-block" type="submit" value="Volver"/>
			</form>
			<?php
		}
	}
}

if(isset($_POST['CrearProducto'])){
	$Nombre = $_POST['Nombre'];
	$Cantidad = $_POST['Cantidad'];
	$Producto = $_POST['Producto'];
	 
	$AgregarProducto = "INSERT INTO productos (Nombre, Cantidad, Tipo_producto, Fecha_creacion) VALUES ('$Nombre', $Cantidad, $Producto, NOW())";
	if($conexion -> query($AgregarProducto)){
 
	$IDProdcuto = mysqli_fetch_assoc($conexion->query("SELECT Id_producto FROM productos WHERE Nombre = '$Nombre' AND Tipo_producto = $Producto AND Cantidad = $Cantidad"));
	$codesDir = "QR/Productos/";   
	$codeFile = $IDProdcuto['Id_producto'].'.png'; 
	$Ruta = $codesDir.$codeFile;
	$ActualizarQR = "UPDATE productos SET QR = '$Ruta' WHERE Id_producto = ".$IDProdcuto['Id_producto'];
		if($conexion -> query($ActualizarQR)){
			include('phpqrcode/qrlib.php');
			QRcode::png($IDProdcuto['Id_producto'], $Ruta, 'H', '10'); 
			echo "<div class='alert alert-dark alert-dismissible'>
				<strong>¡Se creo el producto!</strong> Gracias.
			</div>";
		}else{
			echo "<div class='alert alert-dark alert-dismissible'>
				<strong>¡Se creo el producto!</strong> Sin embargo, no se pudo generar el QR.
			</div>";
		} ?>			
		<form action="../admin/index.php?contenido=newProductos" method="POST" class="form-register"> 
	 		<input class="btn btn-dark btn-block" type="submit" value="Volver"/>
	 	</form> <?php
	}else{
		echo "No se pudo crear el producto";
	} 
}

if (isset($_POST['aggPrestamoMaterial'])) {
	$Id_usuario = $_POST['Id_usuario'];
	$Producto = $_POST['Producto'];
	$Cantidad = $_POST['Cantidad'];
	$Fecha = $_POST['Fecha'];
	$Obsevaciones = $_POST['Obsevaciones'];
	$Enternador = $_POST['Enternador'];
	
	$QrInsertMvto = "INSERT INTO mvto_asignacion(Id_entrenador, Id_usuario, Id_producto, Cantidad, Observaciones, 
	Fecha_asignacion, Fecha_sys, Fecha_devolucion, Estado) 
	VALUES 
	('$Enternador', $Id_usuario, $Producto, $Cantidad, '$Obsevaciones', '$Fecha', now(), NULL, 1)";
	if($conexion -> query($QrInsertMvto)){
		echo "<div class='alert alert-dark alert-dismissible'>
			<strong>¡Se asigno el material!</strong> Gracias.
		</div>";
	}else{
		echo "<div class='alert alert-dark alert-dismissible'>
			<strong>¡Error!</strong> No se pudo asignar el material
		</div>";
		echo $QrInsertMvto;
	} ?>			
	<form action="../admin/index.php?contenido=aggMaterial" method="POST" class="form-register"> 
		<input class="btn btn-dark btn-block" type="submit" value="Volver"/>
	</form>
	<br>
	<form action="../admin/index.php?contenido=viewMaterial" method="POST" class="form-register"> 
		 <input class="btn btn-dark btn-block" type="submit" value="Ver asignacion"/>
	</form>
	 <?php
}

if (isset($_POST['terProcesoMvto'])) {
	$Cantidad = $_POST['Cantidad']; 
	$Id = $_POST['Id'];
	$CantidadInicial = $_POST['CantidadInicial'];
	
	if($CantidadInicial == $Cantidad){
		//Cierra
		
		if(!empty($_POST['Fecha']))
			$Fecha = $_POST['Fecha'];
		else
			$Fecha = date("Y-m-d");
		
		$QrCierra = "UPDATE mvto_asignacion SET Fecha_devolucion = '$Fecha', Estado = 2 WHERE id = $Id";
		if($conexion -> query($QrCierra)){
			echo "<div class='alert alert-dark alert-dismissible'>
				<strong>¡Se cerro el proceso de la asignación!</strong> Gracias.
			</div>";
		}else{
			echo "<div class='alert alert-dark alert-dismissible'>
				<strong>¡Error!</strong> No se pudo asignar el material
			</div>";
			echo $QrCierra;
		}
	}else{
		//Actualiza
		$QrActualiza = "UPDATE mvto_asignacion SET Cantidad = $Cantidad WHERE id = $Id";
		if($conexion -> query($QrActualiza)){
			echo "<div class='alert alert-dark alert-dismissible'>
				<strong>¡Se actualizo el proceso de la asignación!</strong> Gracias.
			</div>";
		}else{
			echo "<div class='alert alert-dark alert-dismissible'>
				<strong>¡Error!</strong> No se pudo asignar el material
			</div>";
			echo $QrActualiza;
		}
	}

	?>
	<form action="../admin/index.php?contenido=viewMaterial" method="POST" class="form-register"> 
		 <input class="btn btn-dark btn-block" type="submit" value="Volver"/>
	</form>
	<?php
}