<?php

error_reporting(E_ALL ^ E_NOTICE);

    if (isset($_POST['aggAdmonFin'])) {
        include 'conexion.php';
        $Cedula=$_POST['Cedula'];
        $Name=$_POST['Name'];
        $Nickname=$_POST['Nickname'];
        $Password=md5($_POST['Password']);
        $Entrenador=$_POST['Entrenador'];
        $Cargo="Asistente al Gym";
        $Permiso=4;
        $Estado=1;

        $PrimeraInfo="INSERT INTO usuario (Id_usuario, Nickname, Password, Name, Cargo, Permiso, Estado, Entrenador) VALUES ($Cedula, $Cedula, '$Password', '$Name', '$Cargo', $Permiso, $Estado, $Entrenador)";

        if ($conexion -> query($PrimeraInfo)) {

            $estado=1;
            $NewCedula=$Cedula; 

        }else{

            $estado=2;
            $PrimeraInfo;
            
        }

    }    
?>

<ol class="breadcrumb"> 
    <li class="breadcrumb-item">Menu administrador</li>
    <li class="breadcrumb-item active">Registro de personal.</li>
</ol>

<form autocomplete="off" action="" method="POST" class="form-register" name="RVH">

    <div class="form-group">
        <label for="exampleInputEmail1">Documento del usuario</label>
        <input class="form-control" id="exampleInputEmail1" type="number" aria-describedby="emailHelp" name="Cedula" required>
    </div>

    <div class="form-group">
        <label for="exampleInputEmail1">Nombre completo</label>
        <input class="form-control" id="exampleInputEmail1" type="text" aria-describedby="emailHelp" name="Name" required>
    </div>

    <div class="form-group">
        <label for="exampleInputEmail1">Contraseña</label>
        <input class="form-control" id="exampleInputEmail1" type="password" aria-describedby="emailHelp" name="Password" required>
    </div> 

    <div class="form-group">
        <label for="Inputipmat">Entrenador</label>
        <input list="Entrenador" class="form-control" id="Inputipmat" type="text" aria-describedby="nameHelp" name="Entrenador" required>
            <datalist id="Entrenador">
            <?php
                $query = $conexion -> query ("SELECT Id_usuario, Name FROM usuario WHERE Permiso = 2");
                while ($admon = mysqli_fetch_array($query)) { echo '<option value="'.$admon['Id_usuario'].'">'.$admon['Name'].'</option>'; }
            ?>
            </datalist>
    </div> 


    <input name="aggAdmonFin" class="btn btn-primary btn-block" type="submit" value="Agregar personal"/>
</form>
<br><br>
 
<meta charset="utf-8">
  <div class="container-fluid">
    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0"> 
      <thead>
        <tr>
          <td>Cedula</td>
          <td>Nombre Completo</td>
          <td>Usuario</td>
          <td>Estado</td> 
          <td>Editar</td> 
        </tr>
      </thead>
<?php

switch ($estado) {
    case '1':
        $ADMON = "SELECT u.Id_usuario, u.Name, u.Nickname, u.Password FROM usuario u WHERE u.Id_usuario = $NewCedula ";
        $listaADMON = $conexion -> query($ADMON);

        while ($VerAdmon=$listaADMON->fetch_array(MYSQLI_BOTH)) {
        echo "<tr>
            <td>".$VerAdmon['Id_usuario']."</td>
            <td>".$VerAdmon['Name']."</td>
            <td>".$VerAdmon['Nickname']."</td>
            <td>Activo</td>
            <td><form action='../admin/index.php?contenido=' method='POST' name='copia' target='_self'>
                  <input type='button' name='view' value='Editar' id='".$VerAdmon['Id_usuario']."' class='btn btn-dark btn-block view_data'/>
            </form></td>
         </tr>";
        }
    break;
    
    case '2':
        ?><tr><th colspan="4">¡UPS! Sucedio algun error :o</th></tr> <?php
    break;
    
    default:
        $ADMON = "SELECT u.Id_usuario, u.Name, u.Nickname, u.Password, u.Estado FROM usuario u WHERE u.Permiso = 4 ";
        $listaADMON = $conexion -> query($ADMON);

        while ($VerAdmon=$listaADMON->fetch_array(MYSQLI_BOTH)) {

        $Val = ($VerAdmon['Estado'] == 0 ) ? $Estado = 'Inactivo' : $Estado = 'Activo' ;

        echo "<tr>
            <td>".$VerAdmon['Id_usuario']."</td>
            <td>".$VerAdmon['Name']."</td>
            <td>".$VerAdmon['Nickname']."</td>
            <td>".$Estado."</td>
            <td><form action='../admin/index.php?contenido=' method='POST' name='copia' target='_self'>
                  <input type='button' name='view' value='Editar' id='".$VerAdmon['Id_usuario']."' class='btn btn-dark btn-block view_data'/>
            </form></td>
        </tr>";
        }
    break;
}
?>
  </table>
</div>

<script>
 $(document).ready(function(){  
      $('#add').click(function(){  
           $('#insert').val("Insert");  
           $('#insert_form')[0].reset();  
      }); 
      $(document).on('click', '.view_data', function(){  
           var employee_id = $(this).attr("id");  
           if(employee_id != '')  
           {  
                $.ajax({  
                     url:"includes/EditarPersona.php",  
                     method:"POST",  
                     data:{employee_id:employee_id},  
                     success:function(data){  
                          $('#employee_detail').html(data);  
                          $('#dataModal').modal('show');  
                     }  
                });  
           }            
      });  
 });  
 </script>
 <div id="dataModal" class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">  
      <div class="modal-dialog modal-lg">  
           <div class="modal-content">  
                <div class="modal-header">
                  <h4 class="modal-title">Editar Persona</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>      
                </div>  
                <div class="modal-body" id="employee_detail">  
                </div> 
                 
           </div>  
      </div>  
 </div>