<ol class="breadcrumb"> 
    <li class="breadcrumb-item">Menu entrenadores</li>
    <li class="breadcrumb-item active">Asignar Producto.</li>
</ol>

<form action="../admin/index.php?contenido=GYMProces" method="POST" class="form-register" name="RVH">

    <div class="form-group">
        <label>Usuario</label>
        <input list="Id_usuario" class="form-control" type="text" aria-describedby="nameHelp" name="Id_usuario" required>
            <datalist id="Id_usuario">
            <?php
                $query = $conexion -> query ("SELECT Id_usuario, Name FROM usuario WHERE Permiso = 4");
                while ($admon = mysqli_fetch_array($query)) { echo '<option value="'.$admon['Id_usuario'].'">'.$admon['Name'].'</option>'; }
            ?>
            </datalist>
    </div> 

    <div class="form-group">
        <label>Producto</label>
        <input list="Producto" class="form-control" type="text" aria-describedby="nameHelp" name="Producto" required>
            <datalist id="Producto">
            <?php
                $query = $conexion -> query ("SELECT Id_producto, Nombre FROM productos WHERE Cantidad > 0");
                while ($admon = mysqli_fetch_array($query)) { echo '<option value="'.$admon['Id_producto'].'">'.$admon['Nombre'].'</option>'; }
            ?>
            </datalist>
    </div>
    
    <div class="form-group">
        <label>Cantidad</label>
        <input class="form-control" min="1" type="number" name="Cantidad" required>
    </div>

    <div class="form-group">
        <label>Fecha prestamo</label>
        <input class="form-control" type="date" name="Fecha" max="<?php echo date("Y-m-d") ?>" required>
    </div>

    <div class="form-group">
        <label>Observaciones</label>
        <textarea class="form-control" type="text" name="Obsevaciones" required></textarea>
    </div> 

    <input type="hidden" name="Enternador" value="<?php echo $User; ?>">

    <input name="aggPrestamoMaterial" class="btn btn-dark btn-block" type="submit" value="Asignar producto"/>
</form>
<br><br>