<center>
<?php

 if(isset($_POST["employee_id"])){ 

  $Dato=$_POST["employee_id"];
?>

	<form action="../admin/index.php?contenido=GYMProces" method="POST" class="form-register" name="RVH">
		<input type="hidden" name="Dato" value="<?php echo $Dato; ?>">
		<input name="EliminarRutina" class="btn btn-danger btn-block" type="submit" value="¡Si!"/>
	</form>

    <br>
    
    <button type='button' class='btn btn-success btn-block' data-dismiss='modal'>¡No!</button>
 

<?php } ?>
</center>