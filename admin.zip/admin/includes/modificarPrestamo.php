<?php
include 'conexion.php';
session_start();
$Nickname = $_SESSION['user'];
$mvto = $_POST['employee_id'];

$QrValidacion = "SELECT ma.Id_entrenador, ma.Estado, ma.Cantidad, ma.Fecha_asignacion, ma.Estado FROM mvto_asignacion ma
INNER JOIN usuario u on u.Id_usuario = ma.Id_entrenador WHERE u.Nickname = '$Nickname' AND ma.Id = $mvto";
$LeerConsulta = $conexion -> query($QrValidacion);
$NroDatos = mysqli_num_rows($LeerConsulta);
$Dato = mysqli_fetch_assoc($LeerConsulta);

if($NroDatos == 0){
    echo "<div class='alert alert-dark alert-dismissible'>
        <strong>Esta asignación la hizo otro entrenador</strong>.
    </div>";
}elseif($Dato['Estado'] == 1){
    $CantidadInicial = $Dato['Cantidad'];
    $FechaPrestamo = $Dato['Fecha_asignacion'];
    ?>
    <form action="../admin/index.php?contenido=GYMProces" method="POST" class="form-register" name="RVH">
        <div class="form-group">
            <label>Cantidad</label>
            <input class="form-control" min="1" max="<?php echo $CantidadInicial ?>" type="number" name="Cantidad" required>
        </div>

        <div class="form-group">
            <label>Fecha devolucion</label>
            <input class="form-control" type="date" name="Fecha" min="<?php echo $FechaPrestamo ?>" max="<?php echo date("Y-m-d") ?>">
        </div> 

        <input type="hidden" name="Id" value = "<?php echo $mvto ?>">
        <input type="hidden" name="CantidadInicial" value = "<?php echo $CantidadInicial ?>">

        <input name="terProcesoMvto" class="btn btn-dark btn-block" type="submit" value="Realizar ajuste"/>
    </form>
<?php }else{
    echo "<div class='alert alert-dark alert-dismissible'>
        <strong>Movimiento sin acciones</strong>.
    </div>";
}
