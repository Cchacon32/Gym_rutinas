<ol class="breadcrumb"> 
    <li class="breadcrumb-item active">Menu de las actividades a realizar.</li>
</ol>
 
<div class="card-deck">
  <div class="card"> 
    <div class="card-body">
      <h5 class="card-title">Registratrar personal</h5>
      <p class="card-text"><a href="?contenido=aggPersonas" class="btn btn-dark btn-block">Ir al modulo</a></p>
    </div>
  </div>
  <div class="card"> 
    <div class="card-body">
      <h5 class="card-title">Asignar rutinas</h5>
      <p class="card-text"><a href="?contenido=aggRutinas" class="btn btn-dark btn-block">Ir al modulo</a></p>
    </div>
  </div> 
</div>
<br> 
