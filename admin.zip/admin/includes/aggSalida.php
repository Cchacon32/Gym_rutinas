<?php 
include 'conexion.php';
date_default_timezone_set('america/bogota');
$Cedula = $_POST['employee_id'];
$Fecha = date("Y-m-d");

$VerEstado = "SELECT Id_asistencia, Estado, Fecha FROM asistencia WHERE Fecha = '$Fecha' AND Cedula = $Cedula AND Estado = 1";
$ConsultaEstado = $conexion ->query($VerEstado);
$NroDatos = mysqli_num_rows($ConsultaEstado);
$Llaves=mysqli_fetch_assoc($ConsultaEstado);

$VerHistorico = "SELECT FechaIng, IFNULL(FechaSal, 'No ha marcado hora de salida') FechaSal, Fecha, TIMESTAMPDIFF(MINUTE, FechaIng, FechaSal) AS Duracion FROM asistencia WHERE Cedula = $Cedula ";
$VerListaAsistencias = $conexion -> query($VerHistorico);

?>

<table border="1" style="width: 100%;">
    <tr align="center">
        <td colspan='4'><strong>HISTORICO DE ENTRADAS Y SALIDAS HOY </strong><?php echo $Fecha ?></td>
    </tr>
    <tr align="center">
        <td>Fecha</td>
        <td>Llegada</td>
        <td>Salida</td>
        <td>Duración</td>
    </tr>
    <?php while ($Ver=$VerListaAsistencias->fetch_array(MYSQLI_BOTH)) {
        echo "<tr align='right'>
            <td>".$Ver['Fecha']."</td>
            <td>".$Ver['FechaIng']."</td>
            <td>".$Ver['FechaSal']."</td>
            <td>".$Ver['Duracion']."</td>
        </tr>";
    } ?>
</table> 
<br>

<?php

if($NroDatos == 0){ ?> 
    <form action="../admin/index.php?contenido=GYMProces" method="POST" class="form-register">
        <input type="hidden" name="Cedula" value="<?php echo $Cedula ?>">
        <input type="hidden" name="Estado" value="1"> 
        <input name="LlegadaSalida" class="btn btn-dark btn-block" type="submit" value="Marcar Llegada"/> 
    </form>
<?php }elseif($Llaves['Estado'] == 1){ ?> 
    <form action="../admin/index.php?contenido=GYMProces" method="POST" class="form-register">
        <input type="hidden" name="Cedula" value="<?php echo $Cedula ?>">
        <input type="hidden" name="Estado" value="2"> 
        <input type="hidden" name="Id_asistencia" value="<?php echo $Llaves['Id_asistencia'] ?>"> 
        <input name="LlegadaSalida" class="btn btn-dark btn-block" type="submit" value="Marcar Salida"/> 
    </form>
<?php } ?>

 