<ol class="breadcrumb"> 
    <li class="breadcrumb-item active">Menú de las actividades a realizar.</li>
</ol>
 
<div class="card-deck">
  <div class="card"> 
    <div class="card-body">
      <h5 class="card-title">Registrar Entrenadores</h5>
      <p class="card-text"><a href="?contenido=aggEntrenadores" class="btn btn-dark btn-block">Ir al modulo</a></p>
    </div>
  </div>
  <div class="card"> 
    <div class="card-body">
      <h5 class="card-title">Registratrar personal</h5>
      <p class="card-text"><a href="?contenido=aggPersonas" class="btn btn-dark btn-block">Ir al modulo</a></p>
    </div>
  </div>
</div>

<br>    

<div class="card-deck">
  <div class="card"> 
    <div class="card-body">
      <h5 class="card-title">Asignar QR personas</h5>
      <p class="card-text"><a href="?contenido=aggQR" class="btn btn-dark btn-block">Ir al modulo</a></p>
    </div>
  </div>

  <div class="card"> 
    <div class="card-body">
      <h5 class="card-title">Ver estadisticas</h5>
      <p class="card-text"><a href="#" class="btn btn-dark btn-block">Ir al modulo</a></p>
    </div>
  </div> 
</div>

<br>    

<div class="card-deck">
  <div class="card"> 
    <div class="card-body">
      <h5 class="card-title">Crear Productos</h5>
      <p class="card-text"><a href="?contenido=newProductos" class="btn btn-dark btn-block">Ir al modulo</a></p>
    </div>
  </div> 
</div>
<br>    
