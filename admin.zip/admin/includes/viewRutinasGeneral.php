<?php
    
    $QueryVerPersonaMani="SELECT R.Id_rutina, R.Id_entrenador, R.Id_persona, U.Name as Entrenador, U2.Name AS Persona, R.Fecha_rutina, R.Rutina, R.Estado FROM rutinas R INNER JOIN usuario U ON U.Id_usuario = R.Id_entrenador INNER JOIN usuario U2 ON U2.Id_usuario = R.Id_persona WHERE R.Id_entrenador = $User ORDER BY R.Id_rutina DESC";
    $ListaPersona = $conexion -> query($QueryVerPersonaMani);

?>    

<ol class="breadcrumb"> 
    <li class="breadcrumb-item">Menu de entrenadores</li> 
    <li class="breadcrumb-item active">Ver rutina</li>
</ol>

<meta charset="utf-8">
<div class="container-fluid">
<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0"> 
    <thead>
        <tr>
            <td>Persona</td>
            <td>Fecha Rutina</td>
            <td>Rutina</td>
            <td>Estado</td>
            <td>Acciones</td> 
        </tr>
    </thead>


<?php

while ($VerPeople=$ListaPersona->fetch_array(MYSQLI_BOTH)) {

    $Val = ($VerPeople['Estado'] == 1 ) ? $Estado = 'Activa' : $Estado = 'Inactiva';
    echo "<tr>
        <td>".$VerPeople['Persona']."</td>
        <td>".$VerPeople['Fecha_rutina']."</td>
        <td>".$VerPeople['Rutina']."</td>
        <td>".$Estado."</td> 
        <td>
            <form action='../admin/index.php?contenido=viewRutinas' method='POST' class='form-register' name='RV''> 
                <input type='hidden' name='Serial' value=".$VerPeople['Id_rutina'].">
                <input type='hidden' name='Enternador' value=".$VerPeople['Id_entrenador'].">
                <input type='hidden' name='Persona' value=".$VerPeople['Id_persona'].">
                <input name='viewRutinas' class='btn btn-dark btn-block' type='submit' value='Ver/Modificar Rutina'/>
            </form>
            <br> ";
            if ($VerPeople['Estado'] == 1) {
              echo "<form action='../admin/index.php?contenido=' method='POST' name='copia' target='_self'>
                  <input type='button' name='view' value='¡Eliminar Rutina!' id='".$VerPeople['Id_rutina']."' class='btn btn-danger btn-block view_data'/>
              </form>";
            }
        echo "</td> 
    </tr>";
} 

?>
  </table>
</div>

<script>
 $(document).ready(function(){  
      $('#add').click(function(){  
           $('#insert').val("Insert");  
           $('#insert_form')[0].reset();  
      }); 
      $(document).on('click', '.view_data', function(){  
           var employee_id = $(this).attr("id");  
           if(employee_id != '')  
           {  
                $.ajax({  
                     url:"includes/Eliminar.php",  
                     method:"POST",  
                     data:{employee_id:employee_id},  
                     success:function(data){  
                          $('#employee_detail').html(data);  
                          $('#dataModal').modal('show');  
                     }  
                });  
           }            
      });  
 });  
 </script>
 <div id="dataModal" class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">  
      <div class="modal-dialog modal-lg">  
           <div class="modal-content">  
                <div class="modal-header">
                  <h4 class="modal-title">¿Esta seguro de eliminar esta rutina?</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>      
                </div>  
                <div class="modal-body" id="employee_detail">  
                </div> 
                 
           </div>  
      </div>  
 </div>