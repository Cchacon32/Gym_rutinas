<?php $Dato=$_POST["employee_id"]; ?>

Visualizacion del QR del producto.
<div align="center">
    <img src="<?php echo $Dato ?>">
</div>


 