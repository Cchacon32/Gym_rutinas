<?php

include 'conexion.php';

if(isset($_POST["employee_id"])){ 

	$Dato=$_POST["employee_id"];

	$ADMON = "SELECT u.Id_usuario, u.Name, u.Nickname, u.Password, u.Entrenador, u.Estado, u.QR FROM usuario u WHERE u.Id_usuario = $Dato ";
	$siguiente=$conexion->query($ADMON);
	$final=mysqli_fetch_assoc($siguiente);
	$Id_usuario=$final['Id_usuario'];
	$Name=$final['Name'];
	$Nickname=$final['Nickname'];
	$Password=$final['Password'];
	$Id_entrenador=$final['Entrenador'];
	$Estado=$final['Estado'];
	$QR=$final['QR'];
    
?>
<form action="../admin/index.php?contenido=GYMProces" method="POST" class="form-register" name="RVH">

<div class="row">
  	<div class="col-md-6">

		<div class="form-group">
		        <label for="exampleInputEmail1">Documento del usuario</label>
		        <input class="form-control" id="exampleInputEmail1" type="number" aria-describedby="emailHelp" name="Cedula" value="<?php echo $Id_usuario ?>" readonly>
		    </div>

		    <div class="form-group">
		        <label for="exampleInputEmail1">Nombre completo</label>
		        <input class="form-control" id="exampleInputEmail1" type="text" aria-describedby="emailHelp" name="Name" value="<?php echo $Name ?>" required>
		    </div>

		    <div class="form-group">
		        <label for="exampleInputEmail1">Contraseña</label>
		        <input class="form-control" id="exampleInputEmail1" type="Password" aria-describedby="emailHelp" name="Password" value="<?php echo $Password ?>" required>
		    </div> 
	</div>
  	<div class="col-md-6">
		<div class="form-group">
	        <label for="Inputipmat">Entrenador</label>
	        <input list="Entrenador" class="form-control" id="Inputipmat" type="text" aria-describedby="nameHelp" name="Entrenador" value="<?php echo $Id_entrenador ?>" required>
	            <datalist id="Entrenador">
	            <?php
	                $query = $conexion -> query ("SELECT Id_usuario, Name FROM usuario WHERE Permiso = 2");
	                while ($admon = mysqli_fetch_array($query)) { echo '<option value="'.$admon['Id_usuario'].'">'.$admon['Name'].'</option>'; }
	            ?>
	            </datalist>
	    </div> 

	    <div class="form-group">
	        <label for="exampleInputEmail1">Estado</label>
	        <select class='form-control'  name='Estado'>
	            <option value="<?php echo $Estado ?>">Cambiar el estado ...</option>
	            <option value='1'>Activo</option> 
	            <option value='0'>Inactivo</option>  
	        </select>
	    </div> 

	    <div class="form-group">
	        <img src="<?php echo  $QR; ?>">
	    </div> 
	</div>
</div> 
    
    <input name="EditPersona" class="btn btn-primary btn-block" type="submit" value="Editar personal"/>
</form>
<br>    
<button type='button' class='btn btn-danger btn-block' data-dismiss='modal'>¡Cancelar!</button> 

<?php } ?>