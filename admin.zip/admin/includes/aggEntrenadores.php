<?php

error_reporting(E_ALL ^ E_NOTICE);

    if (isset($_POST['aggAdmonFin'])) {
        include 'conexion.php';
        $Cedula=$_POST['Cedula'];
        $Name=$_POST['Name'];
        $Nickname=$Cedula;
        $Password=$_POST['Password'];
        $Cargo=$_POST['Cargo']; 
        $Permiso=2;
        $Estado=1;

        $PrimeraInfo="INSERT INTO usuario (Id_usuario, Nickname, Password, Name, Cargo, Permiso, Estado, Entrenador) VALUES ($Cedula, '$Nickname', '$Password', '$Name', '$Cargo', $Permiso, $Estado, $Cedula)";

        if ($conexion -> query($PrimeraInfo)) {

            $estado=1;
            $NewCedula=$Cedula; 

        }else{

            $estado=2;
            
        }

    }    
?>

<ol class="breadcrumb"> 
    <li class="breadcrumb-item">Menu administrador</li>
    <li class="breadcrumb-item active">Registro de Entrenadores.</li>
</ol>

<form action="" method="POST" class="form-register" name="RVH">

    <div class="form-group">
        <label for="exampleInputEmail1">Documento del usuario</label>
        <input class="form-control" id="exampleInputEmail1" type="number" aria-describedby="emailHelp" name="Cedula" required>
    </div>

    <div class="form-group">
        <label for="exampleInputEmail1">Nombre completo</label>
        <input class="form-control" id="exampleInputEmail1" type="text" aria-describedby="emailHelp" name="Name" required>
    </div>
 
    <div class="form-group">
        <label for="exampleInputEmail1">Contraseña</label>
        <input class="form-control" id="exampleInputEmail1" type="password" aria-describedby="emailHelp" name="Password" required>
    </div>

    <div class="form-group">
        <label for="exampleInputEmail1">Cargo</label>
        <input class="form-control" id="exampleInputEmail1" type="text" aria-describedby="emailHelp" name="Cargo" required>
    </div>
 
     <input name="aggAdmonFin" class="btn btn-primary btn-block" type="submit" value="Agregar Entrenador"/>
</form>
<br><br>
 
<meta charset="utf-8">
<div class="container-fluid">
<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0"> 
<thead>
<tr>
<td>Cedula</td>
<td>Nombre Completo</td>
<td>Usuario</td> 
<td>Estado</td> 
<td>Editar</td> 
</tr>
</thead>
<?php

switch ($estado) {
    case '1':
        $ADMON = "SELECT u.Id_usuario, u.Name, u.Nickname, u.Password FROM usuario u WHERE u.Id_usuario = $NewCedula ";
        $listaADMON = $conexion -> query($ADMON);

        while ($VerAdmon=$listaADMON->fetch_array(MYSQLI_BOTH)) {
        echo "<tr>
            <td>".$VerAdmon['Id_usuario']."</td>
            <td>".$VerAdmon['Name']."</td>
            <td>".$VerAdmon['Nickname']."</td>  
        </tr>";
        }
    break;
    
    case '2':
        ?><tr><th colspan="4">¡UPS! Sucedio algun error :o</th></tr> <?php echo $PrimeraInfo;
    break;
    
    default:
     $ADMON = "SELECT u.Id_usuario, u.Name, u.Nickname, u.Password, u.Estado FROM usuario u WHERE u.Permiso = 2 ";
        $listaADMON = $conexion -> query($ADMON);

        while ($VerAdmon=$listaADMON->fetch_array(MYSQLI_BOTH)) {
        $Val = ($VerAdmon['Estado'] == 0 ) ? $Estado = 'Inactivo' : $Estado = 'Activo' ;

        echo "<tr>
            <td>".$VerAdmon['Id_usuario']."</td>
            <td>".$VerAdmon['Name']."</td>
            <td>".$VerAdmon['Nickname']."</td> 
            <td>".$Estado."</td>
            <td><form action='../admin/index.php?contenido=' method='POST' name='copia' target='_self'>
                  <input type='button' name='view' value='Editar' id='".$VerAdmon['Id_usuario']."' class='btn btn-dark btn-block view_data'/>
            </form></td>
        </tr>";
        }
    break;
}
?>
  </table>
</div>

<script>
 $(document).ready(function(){  
      $('#add').click(function(){  
           $('#insert').val("Insert");  
           $('#insert_form')[0].reset();  
      }); 
      $(document).on('click', '.view_data', function(){  
           var employee_id = $(this).attr("id");  
           if(employee_id != '')  
           {  
                $.ajax({  
                     url:"includes/EditarEntrenador.php",  
                     method:"POST",  
                     data:{employee_id:employee_id},  
                     success:function(data){  
                          $('#employee_detail').html(data);  
                          $('#dataModal').modal('show');  
                     }  
                });  
           }            
      });  
 });  
 </script>
 <div id="dataModal" class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">  
      <div class="modal-dialog modal-lg">  
           <div class="modal-content">  
                <div class="modal-header">
                  <h4 class="modal-title">Editar Persona</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>      
                </div>  
                <div class="modal-body" id="employee_detail">  
                </div> 
                 
           </div>  
      </div>  
 </div>