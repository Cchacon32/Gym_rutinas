<?php
    include ("conexion.php");
    $Productos = "SELECT Id_producto, Nombre, Cantidad, Fecha_creacion, QR, Nombre_tipo FROM productos INNER JOIN Tipos_productos on Tipo_producto = Id";
    $VerProductos = $conexion -> query($Productos);

?>

<ol class="breadcrumb"> 
    <li class="breadcrumb-item">Menú de administrador</li>
    <li class="breadcrumb-item active">Productos</li>
</ol>

<form action="../admin/index.php?contenido=GYMProces" method="POST" class="form-register" autocomplete="off">

    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label>Nombre producto</label>
                <input class="form-control" type="text" aria-describedby="emailHelp" name="Nombre" required>
            </div>
        </div> 

        <div class="col-md-6">
            <div class="form-group">
                <label>Cantidad</label>
                <input class="form-control" type="number" aria-describedby="emailHelp" name="Cantidad" required>
            </div> 
        </div> 
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <label>Tipo de productos</label> 
	            <select list="Producto" class="form-control" type="text" name="Producto" required>
                    <option></option>
                    <?php $query = $conexion -> query ("SELECT Id, Nombre_tipo FROM tipos_productos ");
                    while ($admon = mysqli_fetch_array($query)) { echo '<option value="'.$admon['Id'].'">'.$admon['Nombre_tipo'].'</option>'; } ?>
	            </select>
            </div>
        </div>  
    </div>

    <input name="CrearProducto" class="btn btn-dark btn-block" type="submit" value="Registrar Producto"/>

</form>
<br>
<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0"> 
    <thead>
        <tr align="center">
            <td>Nombre</td>
            <td>Cantidad</td>
            <td>Tipo</td>
            <td>Fecha creación</td> 
            <td>QR</td> 
        </tr>
    </thead>
    <tbody>
        <?php while ($VerAdmon=$VerProductos->fetch_array(MYSQLI_BOTH)) {
        echo "<tr>
            <td>".$VerAdmon['Nombre']."</td>
            <td align='right'>".$VerAdmon['Cantidad']."</td>
            <td>".$VerAdmon['Nombre_tipo']."</td>
            <td align='right'>".$VerAdmon['Fecha_creacion']."</td>
            <td>
            <form action='../admin/index.php?contenido=' method='POST' name='copia' target='_self'>
                <input type='button' name='view' value='QR' id='".$VerAdmon['QR']."' class='btn btn-dark btn-block view_data'/>
            </form>
            </td>
        </tr>";
        } ?>   
    </tbody>
</table>


<script>
 $(document).ready(function(){  
      $('#add').click(function(){  
           $('#insert').val("Insert");  
           $('#insert_form')[0].reset();  
      }); 
      $(document).on('click', '.view_data', function(){  
           var employee_id = $(this).attr("id");  
           if(employee_id != '')  
           {  
                $.ajax({  
                     url:"includes/VerQRProductos.php",  
                     method:"POST",  
                     data:{employee_id:employee_id},  
                     success:function(data){  
                          $('#employee_detail').html(data);  
                          $('#dataModal').modal('show');  
                     }  
                });  
           }            
      });  
 });  
 </script>
 <div id="dataModal" class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">  
      <div class="modal-dialog modal-lg">  
           <div class="modal-content">  
                <div class="modal-header">
                  <h4 class="modal-title">QR</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>      
                </div>  
                <div class="modal-body" id="employee_detail">  
                </div> 
                 
           </div>  
      </div>  
 </div>