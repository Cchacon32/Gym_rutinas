<ol class="breadcrumb"> 
    <li class="breadcrumb-item">Menu de entrenadores</li>
    <li class="breadcrumb-item active">Rutinas</li>
</ol>
 
<div class="card-deck">
  <div class="card"> 
    <div class="card-body">
      <h5 class="card-title">Agregar rutinas</h5>
      <p class="card-text"><a href="?contenido=AgRutina" class="btn btn-dark btn-block">Ir al modulo</a></p>
    </div>
  </div>  
  <div class="card"> 
    <div class="card-body">
      <h5 class="card-title">Ver rutinas</h5>
      <p class="card-text"><a href="?contenido=viewRutinasGeneral" class="btn btn-dark btn-block">Ir al modulo</a></p>
    </div>
  </div>
</div>
<br> 
<div class="card-deck">
  <div class="card"> 
    <div class="card-body">
      <h5 class="card-title">Asignar Material</h5>
      <p class="card-text"><a href="?contenido=aggMaterial" class="btn btn-dark btn-block">Ir al modulo</a></p>
    </div>
  </div>  
  <div class="card"> 
    <div class="card-body">
      <h5 class="card-title">Ver material asignado</h5>
      <p class="card-text"><a href="?contenido=viewMaterial" class="btn btn-dark btn-block">Ir al modulo</a></p>
    </div>
  </div>
</div>
<br> 