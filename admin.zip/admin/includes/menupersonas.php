<ol class="breadcrumb"> 
    <li class="breadcrumb-item active">Menu de las actividades a realizar.</li>
</ol>
 
<div class="card-deck">
  <div class="card"> 
    <div class="card-body">
      <h5 class="card-title">Marcar llegada/salida</h5>
      <p class="card-text">
        <form autocomplete='off' action="" method="POST" class="form-register" target="_self">
          <div class="form-group">
            <input type="button" name="aggnota" id="<?php echo $User ?>" class='btn btn-dark btn-block view_data' value="Marcar Llegada ó Salida">
          </div> 
        </form>
      </p>
    </div>
  </div>
  <div class="card"> 
    <div class="card-body">
      <h5 class="card-title">Ver Rutinas</h5>
      <p class="card-text"><a href="?contenido=viewRutinaP" class="btn btn-dark btn-block">Ir al modulo</a></p>
    </div>
  </div> 
</div>
<br> 

<script>
 $(document).ready(function(){  
      $('#add').click(function(){  
           $('#insert').val("Insert");  
           $('#insert_form')[0].reset();  
      }); 
      $(document).on('click', '.view_data', function(){  
           var employee_id = $(this).attr("id");  
           var Name = $(this).attr("Name");  
           if(employee_id != '')  
           {  
                $.ajax({  
                     url:"includes/aggSalida.php",  
                     method:"POST",  
                     data:{employee_id:employee_id},  
                     success:function(data){  
                          $('#employee_detail').html(data);  
                          $('#dataModal').modal('show');  
                     }  
                });  
           }            
      });  
 });  
 </script>

 <div id="dataModal" class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">  
      <div class="modal-dialog modal-lg">  
           <div class="modal-content">  
                <div class="modal-header">
                  <h4 class="modal-title">Seleccione la Llegada o Salida.</em></h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>      
                </div>   
                <div class="modal-body" id="employee_detail">  
                </div> 
                 
           </div>  
      </div>  
 </div>