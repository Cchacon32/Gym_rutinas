<?php

include 'conexion.php';

if(isset($_POST["employee_id"])){ 

	$Dato=$_POST["employee_id"];

	$ADMON = "SELECT u.Name AS Entrenador, r.Fecha_rutina, r.Rutina, CASE WHEN r.Estado = 0 THEN 'Activo' ELSE 'Inactivo' END AS Estado, r.Id_rutina FROM rutinas r INNER JOIN usuario u ON U.Id_usuario = Id_entrenador INNER JOIN usuario u2 ON U2.Id_usuario = Id_persona WHERE r.Id_Rutina = $Dato ";
	$siguiente=$conexion->query($ADMON);
	$final=mysqli_fetch_assoc($siguiente);
	$Entrenador=$final['Entrenador'];
	$Fecha_rutina=$final['Fecha_rutina'];
	$Rutina=$final['Rutina']; 
	$Estado=$final['Estado'];

	$ImagenesRutina = $conexion -> query ("SELECT Id_imagen, Ruta, Nombre FROM imagenesrutina WHERE Estado = 1 AND Id_imagen IN (SELECT Id_imagen FROM rutinas_imagenes WHERE Id_Rutina = $Dato)"); 
	$x=1;

    
?>
 
<div class="row">
  	<div class="col-md-6">

		<div class="form-group">
		        <label for="exampleInputEmail1">Entrenador</label>
		        <input class="form-control" id="exampleInputEmail1" type="text" aria-describedby="emailHelp" name="Cedula" value="<?php echo $Entrenador ?>" readonly>
		</div> 

		<div class="form-group">
		        <label for="exampleInputEmail1">Fecha Rutina</label>
		        <input class="form-control" id="exampleInputEmail1" type="text" aria-describedby="emailHelp" name="Cedula" value="<?php echo $Fecha_rutina ?>" readonly>
		</div> 

	</div>
  	<div class="col-md-6">
		<div class="form-group">
		        <label for="exampleInputEmail1">Rutina</label>
		        <input class="form-control" id="exampleInputEmail1" type="text" aria-describedby="emailHelp" name="Cedula" value="<?php echo $Rutina ?>" readonly>
		</div>  

		<div class="form-group">
		        <label for="exampleInputEmail1">Estado</label>
		        <input class="form-control" id="exampleInputEmail1" type="text" aria-describedby="emailHelp" name="Cedula" value="<?php echo $Estado ?>" readonly>
		</div> 
	</div>

	<div class="col-md-12">
		<div class="form-group">
        <label>Visualización de rutinas</label>
        <table align="center">
            <tr>
	            <?php while ($ver = mysqli_fetch_array($ImagenesRutina)){
	                echo "<td align='center'>
                        <img src='".$ver['Ruta']."' class='form-control' alt='".$ver['Nombre']."' width='160' height='160'>
                        ".$ver['Nombre']."
          			</td>";
	                if ($x%3==0) {
	                    echo "</tr>";
	                }
	                $x++;
	            } ?>
	        </table>        
	    </div> 
	</div>
</div>  
<br>    
<button type='button' class='btn btn-danger btn-block' data-dismiss='modal'>¡Cerrar!</button> 

<?php } ?>