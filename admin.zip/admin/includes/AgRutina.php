<?php 

include 'conexion.php';
$ImagenesRutina = $conexion -> query ("SELECT Id_imagen, Ruta, Nombre FROM imagenesrutina WHERE Estado = 1");
$CantidadImagenes = mysqli_num_rows($ImagenesRutina);
$x=1;

?>

<ol class="breadcrumb"> 
    <li class="breadcrumb-item">Menu de entrenadores</li> 
    <li class="breadcrumb-item active">Agregar rutina</li>
</ol>

<form action="../admin/index.php?contenido=GYMProces" method="POST" class="form-register">

    <input type="hidden" name="CantidadImagenes" value="<?php echo $CantidadImagenes ?>">

    <div class="form-group">
        <label for="Inputipmat">Seleccione a la persona</label>
        <input autocomplete='off' list="Persona" class="form-control" id="Inputipmat" type="text" aria-describedby="nameHelp" name="Persona" required>
            <datalist id="Persona">
            <?php
                $query = $conexion -> query ("SELECT Id_usuario, Name FROM usuario WHERE Permiso = 4 AND Estado = 1");
                while ($admon = mysqli_fetch_array($query)) { echo '<option value="'.$admon['Id_usuario'].'">'.$admon['Name'].'</option>'; }
            ?>
            </datalist>
    </div>

    <div class="form-group">
        <label>Fecha de la rutina</label>
        <input class="form-control" type="date" min="<?php echo date("Y-m-d") ?>" aria-describedby="emailHelp" name="Fecha" required>
    </div> 

    <div class="form-group">
        <label>Visualización de rutinas</label>
        <table>
            <tr>
            <?php  
            while ($ver = mysqli_fetch_array($ImagenesRutina)){
                echo "
                    <td align='center'>
                        <img src='".$ver['Ruta']."' class='form-control' alt='".$ver['Nombre']."' width='150' height='150'>
                        <input type='radio' name='Imagenes".$ver['Id_imagen']."' class='form-control' value='".$ver['Id_imagen']."'>
                    ".$ver['Nombre']."</td>";
                if ($x%6==0) {
                    echo "</tr>";
                }
                $x++;
            }
            ?>
        </table>        
    </div> 

    <div class="form-group">
    	<label>Aspectos de la rutina</label>
	    <textarea class="form-control" id="Rutina" type="text" aria-describedby="emailHelp" placeholder="Observaciones" name="Rutina" required></textarea>
	</div>

	<input type="hidden" name="Enternador" value="<?php echo $User; ?>">
 
     <input name="aggRutina" class="btn btn-primary btn-block" type="submit" value="Agregar Rutina"/>
</form>
<br><br>