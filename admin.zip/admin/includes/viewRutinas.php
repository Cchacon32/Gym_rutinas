<?php

include 'conexion.php'; 

if (isset($_POST['viewRutinas'])) {

   $Enternador = $_POST['Enternador'];
   $Persona = $_POST['Persona'];
   $Serial = $_POST['Serial'];

    $QueryVerPersonaMani="SELECT R.Id_persona, U.Name as Entrenador, U2.Name AS Persona, R.Fecha_rutina, R.Rutina, R.Estado FROM rutinas R INNER JOIN usuario U ON U.Id_usuario = R.Id_entrenador INNER JOIN usuario U2 ON U2.Id_usuario = R.Id_persona WHERE R.Id_rutina = $Serial AND R.Id_entrenador = $Enternador AND R.Id_persona = $Persona ORDER BY R.Id_rutina DESC";
    $siguiente=$conexion->query($QueryVerPersonaMani);
    $final=mysqli_fetch_assoc($siguiente); 
    $Fecha_rutina=$final['Fecha_rutina'];
    $Rutina=$final['Rutina'];
    $Entrenador=$final['Entrenador'];
    $Persona=$final['Persona'];
    $Id_persona=$final['Id_persona'];
    $Estado=$final['Estado'];

    $ImagenesRutina = $conexion -> query ("SELECT Id_imagen, Ruta, Nombre, 1 as Tipo FROM imagenesrutina WHERE Estado = 1 AND Id_imagen IN (SELECT Id_imagen FROM rutinas_imagenes WHERE Id_Rutina = $Serial) UNION ALL SELECT Id_imagen, Ruta, Nombre, 2 as Tipo FROM imagenesrutina WHERE Estado = 1 AND Id_imagen NOT IN (SELECT Id_imagen FROM rutinas_imagenes WHERE Id_Rutina = $Serial)");
    $CantidadImagenes = mysqli_num_rows($ImagenesRutina); 
    $x=1;

?>    

<ol class="breadcrumb"> 
    <li class="breadcrumb-item">>Menu de entrenadores</li>
    <li class="breadcrumb-item">>Menu de Rutinas/li> 
    <li class="breadcrumb-item">>Rutinas</li>
    <li class="breadcrumb-item active">Ver rutina</li>
</ol>

<form action="../admin/index.php?contenido=GYMProces" method="POST" class="form-register" name="RVH">

    <input type="hidden" name="CantidadImagenes" value="<?php echo $CantidadImagenes ?>">

    <div class="form-group">
        <label for="Inputipmat">Seleccione a la persona</label>
        <input autocomplete='off' class="form-control" id="Inputipmat" type="text" aria-describedby="nameHelp" name="Otroo" value="<?php echo $Persona ?>" readonly> 
    </div>

    <div class="form-group">
        <label for="exampleInputEmail1">Fecha de la rutina</label>
        <input class="form-control" id="exampleInputEmail1" type="date" aria-describedby="emailHelp" name="Fecha" value="<?php echo $Fecha_rutina ?>" >
    </div> 

    <div class="form-group">
        <label for="exampleInputEmail1">Aspectos de la rutina</label>
        <textarea class="form-control" id="Rutina" type="text" aria-describedby="emailHelp" placeholder="Observaciones" name="Rutina" required><?php echo $Rutina ?></textarea>
    </div>

    <div class="form-group">
        <label>Visualización de rutinas</label>
        <table>
            <tr>
            <?php  
            while ($ver = mysqli_fetch_array($ImagenesRutina)){
                echo "
                    <td align='center'>
                        <img src='".$ver['Ruta']."' class='form-control' alt='".$ver['Nombre']."' width='150' height='150'>";
                        if ($ver['Tipo'] == 1) {
                            echo "<input type='radio' name='Imagenes".$ver['Id_imagen']."' class='form-control' value='".$ver['Id_imagen']."' checked>";
                        }else{
                            echo "<input type='radio' name='Imagenes".$ver['Id_imagen']."' class='form-control' value='".$ver['Id_imagen']."'>";
                        }

                    echo $ver['Nombre']."</td>";
                if ($x%6==0) {
                    echo "</tr>";
                }
                $x++;
            }
            ?>
        </table>        
    </div> 

    <div class="form-group">
        <label for="exampleInputEmail1">Estado</label>
        <select class='form-control'  name='Estado'>
            <option value="<?php echo $Estado ?>">Cambiar el estado ...</option>
            <option value='1'>Activo</option> 
            <option value='0'>Inactivo</option>  
        </select>
    </div> 

    <input type="hidden" name="Enternador" value="<?php echo $User; ?>">
    <input type="hidden" name="Persona" value="<?php echo $Id_persona; ?>">
    <input type="hidden" name="Serial" value="<?php echo $Serial; ?>">
 
    <?php 

if ($Estado != 0) { ?>
        
    <input name="ActRutina" class="btn btn-primary btn-block" type="submit" value="Modificar Rutina"/>

</form>

<?php }  ?>


<?php } ?>