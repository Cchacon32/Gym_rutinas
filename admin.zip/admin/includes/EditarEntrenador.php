<?php

include 'conexion.php';

if(isset($_POST["employee_id"])){ 

	$Dato=$_POST["employee_id"];

	$ADMON = "SELECT u.Id_usuario, u.Name, u.Nickname, u.Password, u.Entrenador, u.Estado FROM usuario u WHERE u.Id_usuario = $Dato ";
	$siguiente=$conexion->query($ADMON);
	$final=mysqli_fetch_assoc($siguiente);
	$Id_usuario=$final['Id_usuario'];
	$Name=$final['Name'];
	$Nickname=$final['Nickname'];
	$Password=$final['Password']; 
	$Estado=$final['Estado'];
    
?>
<form action="../admin/index.php?contenido=GYMProces" method="POST" class="form-register" name="RVH">

<div class="row">
  	<div class="col-md-6">

		<div class="form-group">
		        <label for="exampleInputEmail1">Documento del usuario</label>
		        <input class="form-control" id="exampleInputEmail1" type="number" aria-describedby="emailHelp" name="Cedula" value="<?php echo $Id_usuario ?>" readonly>
		    </div>

		    <div class="form-group">
		        <label for="exampleInputEmail1">Nombre completo</label>
		        <input class="form-control" id="exampleInputEmail1" type="text" aria-describedby="emailHelp" name="Name" value="<?php echo $Name ?>" required>
		    </div>


	</div>
  	<div class="col-md-6"> 
	    <div class="form-group">
	        <label for="exampleInputEmail1">Contraseña</label>
	        <input class="form-control" id="exampleInputEmail1" type="Password" aria-describedby="emailHelp" name="Password" value="<?php echo $Password ?>" required>
	    </div> 

	    <div class="form-group">
	        <label for="exampleInputEmail1">Estado</label>
	        <select class='form-control'  name='Estado'>
	            <option value="<?php echo $Estado ?>">Cambiar el estado ...</option>
	            <option value='1'>Activo</option> 
	            <option value='0'>Inactivo</option>  
	        </select>
	    </div> 
	</div>
</div> 
    <input type="hidden" name="Entrenador" value="<?php echo $Id_usuario ?>">
    <input name="EditPersona" class="btn btn-primary btn-block" type="submit" value="Editar Entrenador"/>
</form>
<br>    
<button type='button' class='btn btn-danger btn-block' data-dismiss='modal'>¡Cancelar!</button>
 

<?php } ?>