
<?php
   $query = $conexion -> query ("SELECT Id_usuario, Name FROM usuario WHERE QR IS NULL");
?>

<ol class="breadcrumb"> 
   <li class="breadcrumb-item active">Generación de QR a personas.</li>
</ol>

<form class="form-horizontal" method="post" id="codeForm" onsubmit="return false">
   <div class="form-group">
      <label class="control-label">Asistente: </label>
         <select class="form-control" id="content">
            <option></option>
            <?php while ($admon = mysqli_fetch_array($query)) { 
               echo $admon['Id_usuario'].' '.$admon['Name'];
               echo '<option value="'.$admon['Id_usuario'].'">'.$admon['Name'].'</option>'; 
            } ?>
         </select>
   </div>
    
   <div class="form-group">
      <input type="hidden" id="ecc" value="H">
      <input type="hidden" id="size" value="5">
   </div>

   <div class="form-group">
      <label class="control-label"></label>
      <input type="submit" name="submit" id="submit" class="btn btn-dark btn-block" value="Generar código QR">
   </div>

</form> 

<div class="showQRCode"></div>
 