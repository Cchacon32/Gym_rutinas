<?php 
if(isset($_POST) && !empty($_POST)) {
    // phpqrcode/qrlib.php
    include '../phpqrcode/qrlib.php';  
    $codesDir = "../QR/";   
    $codeFile = $_POST['formData'].'.png'; 
    $Ruta = $codesDir.$codeFile;
    QRcode::png($_POST['formData'], $Ruta, 'H', '10'); 
    include 'conexion.php';
    $SqlUpdate = "UPDATE usuario SET QR = 'QR/$codeFile' WHERE Id_usuario = ".$_POST['formData'];
    if($conexion -> query($SqlUpdate)){
        echo '<img class="img-thumbnail" src="QR/'.$codeFile.'" />';
        echo "<div class='alert alert-dark alert-dismissible'>
            <strong>¡Se Genero correctamente el QR, para visualizarlo verlo en las opciones de usuario. 
        </div>"; 
    } 
} else {
    header('location:./');
}