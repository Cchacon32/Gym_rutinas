<?php
session_start();
header("Content-Type: text/html;charset=utf-8");
include("../conexion.php");

@$contenido=$_GET['contenido'];

if (isset($_SESSION['user'])){
  if ($_SESSION['ingresando']==1) {
  $proceso=$_SESSION['registro'];
  $consultauser ="SELECT * FROM usuario WHERE Nickname = '".$_SESSION['user']."'";
  $conuser=mysqli_query($conexion,$consultauser);
  while ($userrow = $conuser->fetch_assoc()){
    $User=$userrow['Id_usuario']; 
    $Permiso=$userrow['Permiso'];
    $hoyIngr = date("d/m/Y");
    date_default_timezone_set('america/bogota');
    $Hora_ingre=date("H:i:s");
    
    $_SESSION['ingresando']=$_SESSION['ingresando']+1;

  }}else{
  $proceso=$contenido;
  $consultauser ="SELECT * FROM usuario WHERE Nickname = '".$_SESSION['user']."'";
  $conuser=mysqli_query($conexion,$consultauser);
  while ($userrow = $conuser->fetch_assoc()){
    @$contenido=$_GET['contenido'];
    $User=$userrow['Id_usuario'];
    $Nombre=$userrow['Name'];
    $Permiso=$userrow['Permiso'];
    $hoyIngr = date("d/m/Y");
    date_default_timezone_set('america/bogota');
    $Hora_ingre=date("H:i:s"); 

    $_SESSION['ingresando']=$_SESSION['ingresando']+1;
}}

  $consultauser ="SELECT * FROM usuario WHERE Nickname = '".$_SESSION['user']."'";
  $conuser=mysqli_query($conexion,$consultauser);
  while ($userrow = $conuser->fetch_assoc()){
    ?>
<!DOCTYPE html>
<html lang="es">

<head>
  <link href="favicon.ico" rel="shortcut icon">
  <meta http-equiv="X-UA-Compatible" content="IE=edge; charset=utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no; charset=utf-8">
  <meta name="description" content="charset=utf-8">
  <meta name="author" content="">
    <meta charset="UTF-8">
  <title>GYM</title> 
  <script src="//code.jquery.com/jquery-3.3.1.min.js"></script> 

  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content=""> 
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="script/ajax_generate_code.js"></script>
    <style>
      body {
          padding-top: 70px;    
      }
    </style>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.3.5/jquery.fancybox.min.css" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.3.5/jquery.fancybox.min.js"></script>
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav" >
    <a class="navbar-brand" href="?contenido=index"><i class="fa fa-globe" aria-hidden="true"></i>  GYM</a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Inicio">
          <a style="color: white;" class="nav-link" href="?contenido=index">
            <i class="fa fa-fw fa-home"></i>
            <span class="nav-link-text">Inicio</span>
          </a>
        </li>
        <?php 

switch ($userrow['Permiso']){   
 
case "2":
include ("models/Entrenadores.php");
break;

case '3':
include ("models/administrativos.php");
break;

case '4':
include ("models/Personas.php");
break; 
  
} ?>
 
      </ul>
      <ul class="navbar-nav sidenav-toggler navbar-dark bg-dark">
        <li class="nav-item">
          <a class="nav-link text-center" id="sidenavToggler" data-class="navbar-fixed-left">
            <i class="fa fa-fw fa-angle-left"></i>
          </a>
        </li>
      </ul>
      <ul class="navbar-nav ml-auto">
        <li class="nav-item dropdown">
            
        </li>
        <li class="nav-item">
            <div class="input-group">
              <span class="input-group-append">
                  <a><i class="nav-link active"><?php echo utf8_encode($userrow['Name']);?> - <?php echo utf8_encode($userrow['Cargo']);}?></i></a>
              </span>
            </div>
        </li>
 
        <li class="nav-item">
          <a class="nav-link" data-toggle="modal" data-target="#exampleModal">
            <i class="fa fa-fw fa-sign-out"></i>Salir</a>
        </li>
      </ul>
    </div>
  </nav>
  <div class="content-wrapper">
    <div class="container-fluid"> 
<?php  

@$contenido=$_GET['contenido']; 
switch ($contenido){  

  case "menurrhh":
    include ("includes/menurrhh.php"); 
  break;

  case "menuadmon":
    include ("includes/menuadmon.php"); 
  break;

  case "aggEntrenadores":
    include ("includes/aggEntrenadores.php"); 
  break; 

  case "menuentrenadores":
    include ("includes/menuentrenadores.php"); 
  break;

  case "aggPersonas":
    include ("includes/aggPersonas.php"); 
  break; 

  case "aggRutinas":
    include ("includes/aggRutinas.php"); 
  break;

  case "AgRutina":
    include ("includes/AgRutina.php"); 
  break;

  case "GYMProces":
    include ("includes/GYMProces.php"); 
  break;

  case "viewRutinas":
    include ("includes/viewRutinas.php"); 
  break;

  case "viewRutinasGeneral":
    include ("includes/viewRutinasGeneral.php"); 
  break;
  
  case "menupersonas":
    include ("includes/menupersonas.php"); 
  break;

  case "viewRutinaP":
    include ("includes/viewRutinaP.php"); 
  break;

  case "aggQR":
    include ("includes/aggQR.php");
  break;  

  case "newProductos":
    include ("includes/newProductos.php");
  break;

  case "aggMaterial":
    include ("includes/aggMaterial.php");
  break;

  case "viewMaterial":
    include ("includes/viewMaterial.php");
  break;

default:
  $contenido="Inicio";
include ("includes/defecto.php");
}
?>
  </div> 
    <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
          <small style="font-family: sans-serif;"><i class="fa fa-globe"></i> GYM </small>
        </div>
      </div>
    </footer> 
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a> 
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">¿Desea cerrar su Sesion?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Seleccione "Salir" si realmente desea finalizar su sesión</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="submit" data-dismiss="modal">Cancelar</button>
            <form action="Cerrar_sesion.php" method="POST" class="form-register" onsubmit="return validar();" enctype="multipart/form-data" name="Cerrar">
            <input class="form-control" id="Inputipmat" type="hidden" aria-describedby="nameHelp" name="N_usuario" value="<?php echo $User;?>">
            <input class="form-control" id="Inputipmat" type="hidden" aria-describedby="nameHelp" name="N_accesos" value="<?php echo $_SESSION['ingresando'];?>">
            <input class="btn btn-primary" type="submit" name="Salir" value="Salir">
            </form>
          </div>
        </div>
      </div>
    </div> 
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script> 
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script> 
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script> 
    <script src="js/sb-admin.min.js"></script> 
    <script src="js/sb-admin-datatables.min.js"></script>
    <script src="js/sb-admin-charts.min.js"></script>
  </div>
</body>

<?php
}else{
  echo '<script>window.location="../index.php";</script>';
}
  ?>
</html>