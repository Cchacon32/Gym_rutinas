<li class="nav-item" data-toggle="tooltip" data-placement="right" title="Reporte">
    <a style="color: white;" class="nav-link" href="?contenido=menurrhh">
    <i class="fa fa-user-circle"></i>
    <span class="nav-link-text"> Menú</span>
    </a>
</li>